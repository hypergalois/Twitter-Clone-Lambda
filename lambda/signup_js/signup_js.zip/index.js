const mysql = require('mysql');
const bcrypt = require('bcryptjs');

const rds_host = 'RDS_HOST=twitter-clone.cndejnjkpsl8.us-east-1.rds.amazonaws.com'
const usernameDB = 'admin_twitter_sd'
const passwordDB = 'fbPdbAw!&c685Z1rTfw6'
const dbname = 'twitter'

const pool = mysql.createPool({
    connectionLimit: 10,
    host: rds_host,
    user: usernameDB,
    password: passwordDB,
    database: dbname
});

exports.handler = async (event, context) => {
    const body = JSON.parse(event.body);

    const nombre = body.nombre;
    const user = body.user;
    const email = body.email;
    const password = body.password;
    const frase = body.frase;

    const hashedPassword = await bcrypt.hash(password, 10);

    return new Promise((resolve, reject) => {
        pool.query('SELECT * FROM usuarios WHERE username = ?', [user], (error, results) => {
            if (error) {
                console.error(error);
                resolve({
                    statusCode: 500,
                    headers: { 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: 'Internal server error' })
                });
            } else if (results.length > 0) {
                resolve({
                    statusCode: 400,
                    headers: { 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: 'Username already exists' })
                });
            } else {
                pool.query(
                    'INSERT INTO usuarios (nombre, username, email, password, recovery_phrase) VALUES (?, ?, ?, ?, ?)',
                    [nombre, user, email, hashedPassword, frase],
                    (error, results) => {
                        if (error) {
                            console.error(error);
                            resolve({
                                statusCode: 500,
                                headers: { 'Access-Control-Allow-Origin': '*' },
                                body: JSON.stringify({ message: 'Internal server error' })
                            });
                        } else {
                            resolve({
                                statusCode: 200,
                                headers: { 'Access-Control-Allow-Origin': '*' },
                                body: JSON.stringify({ message: 'Registration successful', user: user, id_user: results.insertId })
                            });
                        }
                    }
                );
            }
        });
    });
};
