const mysql = require('mysql');

const rds_host = 'your_host_here';
const usernameDB = 'your_username_here';
const passwordDB = 'your_password_here';
const dbname = 'your_dbname_here';

const pool = mysql.createPool({
    connectionLimit: 10,
    host: rds_host,
    user: usernameDB,
    password: passwordDB,
    database: dbname
});

exports.handler = async (event, context) => {
    const username = event.queryStringParameters.username;
    const newPassword = event.queryStringParameters.new_password;

    return new Promise((resolve, reject) => {
        // First, get the user ID for later response
        pool.query('SELECT id_user FROM usuarios WHERE username = ?', [username], (error, results) => {
            if (error) {
                console.error(error);
                resolve({
                    statusCode: 500,
                    headers: {
                        "Access-Control-Allow-Headers": "Content-Type",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
                    },
                    body: JSON.stringify({ res: 'fail', error: 'serverError' })
                });
            } else if (results.length === 0) {
                resolve({
                    statusCode: 404,
                    headers: {
                        "Access-Control-Allow-Headers": "Content-Type",
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
                    },
                    body: JSON.stringify({ res: 'fail', error: 'userNotFound' })
                });
            } else {
                const userId = results[0].id_user;

                // Now, update the password
                pool.query('UPDATE usuarios SET password = ? WHERE username = ?', [newPassword, username], (error, results) => {
                    if (error) {
                        console.error(error);
                        resolve({
                            statusCode: 500,
                            headers: {
                                "Access-Control-Allow-Headers": "Content-Type",
                                "Access-Control-Allow-Origin": "*",
                                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
                            },
                            body: JSON.stringify({ res: 'fail', error: 'serverError' })
                        });
                    } else {
                        resolve({
                            statusCode: 200,
                            headers: {
                                "Access-Control-Allow-Headers": "Content-Type",
                                "Access-Control-Allow-Origin": "*",
                                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
                            },
                            body: JSON.stringify({ res: 'ok', id_user: userId })
                        });
                    }
                });
            }
        });
    });
};
